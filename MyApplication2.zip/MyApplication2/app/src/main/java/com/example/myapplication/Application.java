package com.example.myapplication;

public class Application {

    private String nomAppli;
    private String userAppli;
    private String mdpAppli;

    public Application(String nomAppli, String userAppli, String mdpAppli) {
        this.nomAppli = nomAppli;
        this.userAppli = userAppli;
        this.mdpAppli = mdpAppli;
    }

    public String getNomAppli() {
        return nomAppli;
    }

    public String getUserAppli() {
        return userAppli;
    }

    public String getMdpAppli() {
        return mdpAppli;
    }

    public void setNomAppli(String nomAppli) {
        this.nomAppli = nomAppli;
    }

    public void setUserAppli(String userAppli) {
        this.userAppli = userAppli;
    }

    public void setMdpAppli(String mdpAppli) {
        this.mdpAppli = mdpAppli;
    }
}

package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class AppliAdapter extends ArrayAdapter<Application> {
    public AppliAdapter(@NonNull Context context, int resource) {
        super(context, resource);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        View v;
        LayoutInflater layoutInflater = (LayoutInflater)getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        v = layoutInflater.inflate(R.layout.appli_cell,null);
        Application currentApp = getItem(position);

        TextView  titreappli = (TextView)v.findViewById(R.id.titreappli);
        TextView  user = (TextView)v.findViewById(R.id.user);
        TextView  mdp = (TextView)v.findViewById(R.id.mdp);

        titreappli.setText(currentApp.getNomAppli());
        user.setText(currentApp.getUserAppli());
        mdp.setText(currentApp.getMdpAppli());










        return v;



    }
}

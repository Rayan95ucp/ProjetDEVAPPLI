package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Arrays;

public class Liste2 extends AppCompatActivity {

            ArrayAdapter<String> adapter;
            EditText editText;
            ArrayList<String> itemList;
            private Accelerometer accelerometer;




    protected void onCreate(Bundle savedInstanceState) {

                super.onCreate(savedInstanceState);
                setContentView(R.layout.activity_main);
                accelerometer =new Accelerometer(this);
                accelerometer.setListener(new Accelerometer.Listener() {
                    @Override
                    public void onTranslation(float tx, float ty, float tz) {
                        if(tx > 2.0f){
                            Intent i = new Intent(Liste2.this, MainActivity.class);
                            finish();
                            startActivity(i);
                        }
                        else if(tx < -2.0f){
                            Intent i = new Intent(Liste2.this, MainActivity.class);
                            finish();
                            startActivity(i);
                        }
                    }
                });

            super.onResume();

            accelerometer.register();


            super.onPause();

            accelerometer.unregister();









        String[] items={"Snapchat,ADM95,mdp95","Twitter,ADW95,mdp93","Discord,ADZ,mdp76"};
                itemList=new ArrayList<String>(Arrays.asList(items));
                adapter=new ArrayAdapter<String>(this,R.layout.list_item,R.id.txtview,itemList);
                ListView listV=(ListView)findViewById(R.id.list);
                listV.setAdapter(adapter);
                editText=(EditText)findViewById(R.id.txtInput);
                 Button btAdd=(Button)findViewById(R.id.btAdd);
                btAdd.setOnClickListener(new View.OnClickListener() {

                    @Override
            public void onClick(View v) {
                String newItem=editText.getText().toString();
                itemList.add(newItem);
                adapter.notifyDataSetChanged();
            }

        });

    }

}
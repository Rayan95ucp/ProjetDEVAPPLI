package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class Formulaire extends AppCompatActivity {

    EditText appli;
    EditText user;
    EditText password;
    Button btnSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formulaire);
        appli=findViewById(R.id.et_appli);
        user=findViewById(R.id.et_username);
        password=findViewById(R.id.et_password);
        btnSubmit=findViewById(R.id.bt_submit);

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                appli.getText().toString().equals("nomAppli");






                Intent intent = new Intent(Formulaire.this, Liste.class);
                startActivity(intent);
            }
        });
    }
}
package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class Liste extends AppCompatActivity {

    private ArrayList<Application> mesAppli;
    private AppliAdapter appliAdapter;
    private ListView mListeLV;
    Button addBtn;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_liste);


        mListeLV = (ListView)findViewById(R.id.maListe);
        addBtn=findViewById(R.id.button2);


        appliAdapter = new AppliAdapter(getApplicationContext(),0);

        mesAppli = new ArrayList<>();

        mesAppli.add(new Application("Snapchat","user95","mdp95"));
        mesAppli.add(new Application("Twitter","user95","mdp95"));
        mesAppli.add(new Application("Messenger","user95","mdp95"));
        mesAppli.add(new Application("Ucp","user95","mdp95"));
        mesAppli.add(new Application("Discord","user95","mdp95"));
        mesAppli.add(new Application("Teams","user95","mdp95"));



        mListeLV.setAdapter(appliAdapter);
        appliAdapter.addAll(mesAppli);

        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Liste.this, Formulaire.class);
                startActivity(intent);
            }
        });



    }
}